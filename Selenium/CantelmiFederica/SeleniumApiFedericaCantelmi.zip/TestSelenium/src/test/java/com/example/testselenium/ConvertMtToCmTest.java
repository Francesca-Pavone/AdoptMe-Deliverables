package com.example.testselenium;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

import static com.codeborne.selenide.Condition.attribute;

public class ConvertMtToCmTest {

    @Test
    public void testItToEngTranslation() {
        ConvertMtToCm convertMtToCm = new ConvertMtToCm();
        int cmOutput = convertMtToCm.mtToCmConversion("3");
        assertEquals(cmOutput, 300);
    }
}
