package com.example.testselenium;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class ConvertMtToCm {
    /**
     * FEDERICA CANTELMI
     */
    public int mtToCmConversion(String metersInput) {
        System.setProperty("webdriver.chrome.driver", "C:/Users/feder/IdeaProjects/TestSelenium/src/test/java/Driver/chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://convertlive.com/it/u/convertire/metri/a/centimetri");

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"convert-value\"]")).click();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebElement stringInput = driver.findElement(By.xpath("//*[@id=\"convert-value\"]"));
        stringInput.sendKeys(metersInput);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"convert-submit\"]")).click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String cmOutput = driver.findElement(By.xpath("//*[@id=\"converter\"]/div[4]/p/span[4]")).getAttribute("textContent");

        driver.close();

        return Integer.parseInt(cmOutput);
    }
}
