package com.ispwproject.seleniumapifrancescapavone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConvertCelsiusSelenium {

    /**
     * TEST AUTHOR -> Francesca Pavone Salafia
     */

    public Double celsiusToFahrenheit(String celsius) {
        System.setProperty("webdriver.chrome.driver", "/Users/francesca/IdeaProjects/PresidentOfTheRepublic/src/test/java/Driver/chromedriver");
        WebDriver driver = new ChromeDriver();

        driver.get("https://www.rapidtables.com/convert/temperature");
        driver.manage().window().fullscreen();

        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        driver.findElement(By.xpath("/html/body/div[5]/div[2]/div[1]/div[2]/div[2]/button[1]")).click();

        try {
            Thread.sleep(2000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        driver.findElement(By.xpath("/html/body/div[7]/div/span")).click();

        // insert input
        WebElement celsiusInput = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[3]/td[2]/input"));
        celsiusInput.sendKeys(celsius);
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        //click convert
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[3]/td[4]/input")).click();

        //wait for result
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        //retrieve result
        String fahrenheitString = driver.findElement(By.id("f")).getAttribute("value");
        driver.close();

        return Double.parseDouble(fahrenheitString);
    }
}
