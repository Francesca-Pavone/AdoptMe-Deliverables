package com.ispwproject.seleniumapifrancescapavone;


import org.checkerframework.checker.units.qual.C;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConvertCelsiusTest {

    /**
     * TEST AUTHOR -> Francesca Pavone Salafia
     */

    @Test
    public void testConvertCelsius() {
        ConvertCelsiusSelenium convertCelsiusSelenium = new ConvertCelsiusSelenium();
        Double fahrenheit = convertCelsiusSelenium.celsiusToFahrenheit("25.5");
        assertEquals(fahrenheit, 77.9);
    }

}
